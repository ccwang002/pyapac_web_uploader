http client/server for asyncio
==============================

.. image:: https://raw.github.com/KeepSafe/aiohttp/master/docs/_static/aiohttp-icon-128x128.png
  :height: 64px
  :width: 64px
  :alt: aiohttp logo

.. image:: https://secure.travis-ci.org/KeepSafe/aiohttp.png
  :target:  https://secure.travis-ci.org/KeepSafe/aiohttp
  :align: right

Features
--------

- Supports both client and server side of HTTP protocol.
- Supports Web-Sockets out-of-the-box.
- Web-server has middlewares and pluggable routing.


Requirements
------------

- Python >= 3.3
- asyncio https://pypi.python.org/pypi/asyncio


License
-------

``aiohttp`` is offered under the Apache 2 license.


Documentation
-------------

http://aiohttp.readthedocs.org/

Source code
------------

The latest developer version is available in a github repository:
https://github.com/KeepSafe/aiohttp


Getting started
---------------

Client
^^^^^^

To retrieve something from the web::

  import aiohttp

  def get_body(url):
      response = yield from aiohttp.request('GET', url)
      return (yield from response.read())

You can use the get command like this anywhere in your ``asyncio``
powered program::

  response = yield from aiohttp.request('GET', 'http://python.org')
  body = yield from response.read()
  print(body)

If you want to use timeouts for aiohttp client side please use standard
asyncio approach::

   yield from asyncio.wait_for(request('GET', url), 10)

Server
^^^^^^

In aiohttp 0.12 we've added highlevel API for web HTTP server.

There is simple usage example::

    import asyncio
    from aiohttp import web


    @asyncio.coroutine
    def handle(request):
        name = request.match_info.get('name', "Anonymous")
        text = "Hello, " + name
        return web.Response(body=text.encode('utf-8'))


    @asyncio.coroutine
    def init(loop):
        app = web.Application(loop=loop)
        app.router.add_route('GET', '/{name}', handle)

        srv = yield from loop.create_server(app.make_handler(),
                                            '127.0.0.1', 8080)
        print("Server started at http://127.0.0.1:8080")
        return srv

    loop = asyncio.get_event_loop()
    loop.run_until_complete(init(loop))
    loop.run_forever()

CHANGES
=======

0.14.4 (01-29-2015)
-------------------

- Fix issue with error during constructing of url with regex parts #264

0.14.3 (01-28-2015)
-------------------

- Use path='/' by default for cookies #261

0.14.2 (01-23-2015)
-------------------

- Connections leak in BaseConnector #253

- Do not swallow websocket reader exceptions #255

- web.Request's read, text, json are memorized #250


0.14.1 (01-15-2015)
-------------------

- HttpMessage._add_default_headers does not overwrite existing headers #216

- Expose multidict classes at package level

- add `aiohttp.web.WebSocketResponse`

- According to RFC 6455 websocket subprotocol preference order is
  provided by client, not by server

- websocket's ping and pong accept optional message parameter

- multidict views do not accept `getall` parameter anymore, it
  returns the full body anyway.

- multidicts have optional Cython optimization, cythonized version of multidicts is
  about 5 times faster than pure Python.

- multidict.getall() returns `list`, not `tuple`.

- Backward imcompatible change: now there are two mutable multidicts
  (`MultiDict`, `CIMultiDict`) and two immutable multidict proxies
  (`MultiDictProxy` and `CIMultiDictProxy`). Previous edition of
  multidicts was not a part of public API BTW.

- Router refactoring to push Not Allowed and Not Found in middleware processing

- Convert `ConnectionError` to `aiohttp.DisconnectedError` and don't
  eat `ConnectionError` exceptions from web handlers.

- Remove hop headers from Response class, wsgi response still uses hop headers.

- Allow to send raw chunked encoded response.

- Allow to encode output bytes stream into chunked encoding.

- Allow to compress output bytes stream with `deflate` encoding.

- Server has 75 seconds keepalive timeout now, was non-keepalive by default.

- Application doesn't accept `**kwargs` anymore (#243).

- Request is inherited from dict now for making per-request storage to
  middlewares (#242).

